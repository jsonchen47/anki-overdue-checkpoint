"""Build a reproducible, flat Anki add-on archive."""
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "overdue_checkpoint"
DIST = ROOT / "dist"
VERSION = "0.1.0"


def build():
    DIST.mkdir(exist_ok=True)
    destination = DIST / f"overdue-checkpoint-{VERSION}.ankiaddon"
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(SOURCE.iterdir()):
            if not path.is_file() or path.suffix not in (".py", ".json", ".md"):
                continue
            info = zipfile.ZipInfo(path.name, (2026, 11, 25, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    print(destination)
    return destination


if __name__ == "__main__":
    build()
