"""Launch real Anki with an isolated, synthetic profile and the packaged add-on.

Run with the Python that contains aqt. Uses no personal profile or sync account.
"""
import json
import os
from pathlib import Path
import sys
import tempfile
import traceback
import zipfile

ROOT = Path(__file__).resolve().parents[1]
FSRS = "--fsrs" in sys.argv
GUIDE = "--guide" in sys.argv
SCHEDULER = "fsrs" if FSRS else "sm2"
SAVED_INTERVAL = 240 if GUIDE else 320
NATIVE_BONUS = 0 if GUIDE else 10
sys.path.insert(0, str(ROOT))
from build import build

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu")

import aqt
from aqt import gui_hooks
from aqt.profiles import ProfileManager
from aqt.qt import QApplication, QDialog, QTimer, QSpinBox, QCheckBox
from anki.collection import Collection


artifact_dir = ROOT / "docs/images" if GUIDE else ROOT / "test-results"
artifact_dir.mkdir(parents=True, exist_ok=True)
tmp = tempfile.TemporaryDirectory(prefix="overdue-checkpoint-qa-")
base = Path(tmp.name)
pm = ProfileManager(base)
pm.setupMeta()
pm.meta.update(defaultLang="en_US", firstRun=False, check_for_updates=False)
pm.create("Checkpoint QA")
pm.load("Checkpoint QA")
pm.profile.update(autoSync=False, syncKey=None)
pm.save()
pm.db.close()
profile = base / "Checkpoint QA"
profile.mkdir(exist_ok=True)
col = Collection(str(profile / "collection.anki2"))
col.crt -= 400 * 86400
col.close()
col = Collection(str(profile / "collection.anki2"))
col.set_config("fsrs", FSRS)
col.set_config("cardStateCustomizer", "" if GUIDE else """
if (states.good.normal?.review) {
    states.good.normal.review.scheduledDays += 10;
}
""")
cases = {}
for name in ("start", "resume", "fail", "boundary"):
    did = col.decks.id("QA " + name)
    note = col.new_note(col.models.by_name("Basic"))
    note["Front"] = "Overdue Checkpoint QA: " + name
    note["Back"] = "Synthetic test card"
    if GUIDE and name == "start":
        note["Front"] = "First review: a card more than 60 days overdue"
        note["Back"] = "Remembered it? Hard, Good, or Easy schedules a seven-day check."
    elif GUIDE and name == "resume":
        note["Front"] = "Seven days later: confirm that you still remember"
        note["Back"] = (
            "This example saved a regular interval of 240 days (about eight months). "
            "Another successful recall restores that saved interval.")
    col.add_note(note, did)
    card = note.cards()[0]
    card.type = card.queue = 2
    card.reps = 10
    card.factor = 2500
    card.ivl = 100
    card.due = col.sched.today - (60 if name == "boundary" else 61)
    if name in ("resume", "fail"):
        card.ivl = 7
        card.due = col.sched.today
        card.custom_data = json.dumps({"ocp": [1, SAVED_INTERVAL, card.due, card.reps, 7]})
    col.update_card(card)
    cases[name] = {"cid": card.id, "did": did,
                   "native_good": col._backend.get_scheduling_states(card.id).good.normal.review.scheduled_days}
col.close()
addon_dir = base / "addons21" / "overdue_checkpoint"
addon_dir.mkdir(parents=True)
package = build()
with zipfile.ZipFile(package) as archive:
    archive.extractall(addon_dir)
(addon_dir / "meta.json").write_text(json.dumps({"name": "Overdue Checkpoint", "disabled": False}))

report = {"anki_version": aqt.appVersion, "scheduler": SCHEDULER,
          "cases": [], "isolated_profile": True}
stage = 0
names = list(cases)
finished = False
queued_questions = set()


def finish(error=None):
    global finished
    if finished:
        return
    finished = True
    report["passed"] = error is None
    if error:
        report["error"] = error
    (artifact_dir / f"gui-smoke-{SCHEDULER}.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2), flush=True)
    QTimer.singleShot(0, aqt.mw.unloadProfileAndExit)


def safe(fn):
    def run(*args):
        try:
            return fn(*args)
        except Exception:
            finish(traceback.format_exc())
    return run


@safe
def start_case():
    if stage == len(names):
        check_settings()
        return
    aqt.mw.col.decks.select(cases[names[stage]]["did"])
    aqt.mw.moveToState("overview")
    # Overview renders asynchronously. Follow the normal UI transition rather
    # than allowing a late deck-browser render to replace the review document.
    QTimer.singleShot(700, safe(lambda: aqt.mw.moveToState("review")))


@safe
def question(card):
    if stage >= len(names) or card.id != cases[names[stage]]["cid"]:
        return
    key = (stage, card.id)
    if key in queued_questions:
        return
    queued_questions.add(key)
    QTimer.singleShot(300, ready_to_show_answer)


@safe
def ready_to_show_answer():
    reviewer = aqt.mw.reviewer
    def ready(value):
        if value and aqt.mw.state == "review":
            reviewer._showAnswer()
        else:
            QTimer.singleShot(100, ready_to_show_answer)
    reviewer.web.evalWithCallback("typeof _showAnswer === 'function'", safe(ready))


@safe
def shown_answer(card):
    if stage >= len(names) or card.id != cases[names[stage]]["cid"]:
        return
    QTimer.singleShot(200, check_answer)


@safe
def check_answer():
    if stage >= len(names) or aqt.mw.reviewer.state != "answer":
        return
    reviewer = aqt.mw.reviewer
    if not reviewer._states_mutated:
        QTimer.singleShot(50, check_answer)
        return
    name = names[stage]
    states = reviewer.get_scheduling_states()
    expected = 7 if name == "start" else max(SAVED_INTERVAL, cases[name]["native_good"] + NATIVE_BONUS) if name in ("resume", "fail") else cases[name]["native_good"] + NATIVE_BONUS
    assert states.good.normal.review.scheduled_days == expected, (name, states)
    # Inspect actual rendered DOM, not just Python's scheduling result.
    reviewer.bottom.web.evalWithCallback(
        'Array.from(document.querySelectorAll("button[data-ease]")).map(b => b.innerText)',
        safe(lambda labels: got_labels(name, expected, labels)))


@safe
def got_labels(name, expected, labels):
    if stage >= len(names) or names[stage] != name:
        return
    assert len(labels) == 4, labels
    if name == "start":
        normalized = labels[2].translate(str.maketrans("", "", " \u2068\u2069"))
        assert "7d" in normalized, labels
        aqt.mw.grab().save(str(artifact_dir / f"review-checkpoint-{SCHEDULER}.png"))
    if GUIDE and name == "resume":
        aqt.mw.grab().save(str(artifact_dir / "review-confirmation.png"))
    report["cases"].append({"name": name, "button_labels": labels, "expected_interval": expected})
    aqt.mw.reviewer._answerCard(1 if name == "fail" else 3)


@safe
def answered(reviewer, card, ease):
    global stage
    name = names[stage]
    saved = aqt.mw.col.get_card(card.id)
    if name == "start":
        assert saved.ivl == 7 and saved.due == aqt.mw.col.sched.today + 7
        marker = json.loads(saved.custom_data)["ocp"]
        assert marker[1] == cases[name]["native_good"] + NATIVE_BONUS
    elif name == "resume":
        assert saved.ivl >= SAVED_INTERVAL and "ocp" not in json.loads(saved.custom_data or "{}")
    elif name == "fail":
        assert saved.lapses == 1 and "ocp" not in json.loads(saved.custom_data or "{}")
    else:
        assert saved.ivl == cases[name]["native_good"] + NATIVE_BONUS
    stage += 1
    QTimer.singleShot(300, start_case)


@safe
def check_settings():
    from overdue_checkpoint import integration
    def inspect_dialog():
        dialog = QApplication.activeModalWidget()
        assert isinstance(dialog, QDialog)
        spins = dialog.findChildren(QSpinBox)
        assert sorted(s.value() for s in spins) == [7, 60]
        assert dialog.findChild(QCheckBox).isChecked()
        dialog.grab().save(str(artifact_dir / f"settings-{SCHEDULER}.png"))
        spins[0].setValue(45)
        spins[1].setValue(5)
        dialog.accept()
    QTimer.singleShot(200, safe(inspect_dialog))
    integration.open_settings()
    config = aqt.mw.addonManager.getConfig("overdue_checkpoint")
    assert config["overdue_days"] == 45 and config["checkpoint_days"] == 5
    report["settings_saved"] = config
    # Also exercise native archive installer and manifest compatibility.
    result = aqt.mw.addonManager.install(str(package))
    assert result.compatible, result
    report["native_package_install"] = str(result)
    finish()


@safe
def profile_open():
    assert str(base) in aqt.mw.col.path
    QTimer.singleShot(2000, start_case)


gui_hooks.profile_did_open.append(profile_open)
gui_hooks.reviewer_did_show_question.append(question)
gui_hooks.reviewer_did_show_answer.append(shown_answer)
gui_hooks.reviewer_did_answer_card.append(answered)
# Anki's single-instance socket is global even with a separate --base. Give
# this QA process its own socket so an open personal Anki is never reused.
aqt.AnkiApp.KEY = "anki-overdue-checkpoint-qa-" + str(os.getpid())
original_app_init = aqt.AnkiApp.__init__
def instrumented_app_init(self, argv):
    original_app_init(self, argv)
    QTimer.singleShot(45000, lambda: finish("GUI smoke test timed out"))
aqt.AnkiApp.__init__ = instrumented_app_init
app = aqt._run(["anki", "-b", str(base), "-p", "Checkpoint QA", "-l", "en"], exec=False)
if app is None:
    raise RuntimeError("Anki did not create the isolated application")
code = app.exec()
sys.exit(0 if report.get("passed") else 1)
