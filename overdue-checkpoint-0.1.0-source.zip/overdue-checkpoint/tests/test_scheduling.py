"""Exercise the shipped policy against Anki's actual Rust-backed scheduler."""
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest

from anki.collection import Collection
from anki.scheduler.v3 import CardAnswer, SchedulingState, SchedulingStates

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("checkpoint_core", ROOT / "overdue_checkpoint/core.py")
core = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = core
spec.loader.exec_module(core)


class PolicyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = str(Path(self.tmp.name) / "collection.anki2")
        self.col = Collection(self.path)
        self.col.crt -= 400 * 86400
        self.col.close()
        self.col = Collection(self.path)

    def tearDown(self):
        self.col.close()
        self.tmp.cleanup()

    def card(self, overdue=61, interval=100, fsrs=False, data=""):
        if fsrs:
            self.col.set_config("fsrs", True)
        note = self.col.new_note(self.col.models.by_name("Basic"))
        note["Front"] = "Question"
        note["Back"] = "Answer"
        self.col.add_note(note, 1)
        card = note.cards()[0]
        card.queue = card.type = 2
        card.ivl = interval
        card.due = self.col.sched.today - overdue
        card.factor = 2500
        card.reps = 10
        card.custom_data = data
        self.col.update_card(card)
        return card

    def states(self, card):
        states = self.col._backend.get_scheduling_states(card.id)
        states.current.custom_data = card.custom_data
        return states

    def prepare(self, card, settings=None, maximum=36500):
        return core.prepare(self.states(card), core.CardSnapshot.from_card(card),
                            self.col.sched.today, settings or core.Settings(), maximum)

    def answer(self, card, states, rating=CardAnswer.GOOD):
        card.start_timer()
        self.col.sched.answer_card(self.col.sched.build_answer(
            card=card, states=states, rating=rating))
        card.load()

    def advance(self, days):
        # Move only the synthetic collection's creation date, then reopen to
        # refresh the backend's day cache. No system-clock or live-profile edits.
        self.col.crt -= days * 86400
        self.col.close()
        self.col = Collection(self.path)

    def test_threshold_boundaries(self):
        for overdue in (-5, 0, 59, 60, 61, 200):
            with self.subTest(overdue=overdue):
                card = self.card(overdue=overdue)
                original = self.states(card)
                before = original.SerializeToString()
                result, status = self.prepare(card)
                if overdue > 60:
                    self.assertEqual(status, "checkpoint")
                    for name in ("hard", "good", "easy"):
                        self.assertEqual(getattr(result, name).normal.review.scheduled_days, 7)
                else:
                    self.assertEqual(status, "normal")
                    self.assertEqual(result, original)
                self.assertEqual(before, original.SerializeToString())

    def test_full_lifecycle_all_recalled_ratings_and_both_schedulers(self):
        for fsrs in (False, True):
            for rating, name in ((CardAnswer.HARD, "hard"), (CardAnswer.GOOD, "good"),
                                 (CardAnswer.EASY, "easy")):
                with self.subTest(fsrs=fsrs, rating=name):
                    self.col.set_config("fsrs", fsrs)
                    card = self.card(data='{"other":42}')
                    native = self.states(card)
                    saved = getattr(native, name).normal.review.scheduled_days
                    prepared, _ = self.prepare(card)
                    before_reps, before_lapses = card.reps, card.lapses
                    self.answer(card, prepared, rating)
                    self.assertEqual(card.ivl, 7)
                    self.assertEqual(card.due, self.col.sched.today + 7)
                    self.assertEqual(card.reps, before_reps + 1)
                    self.assertEqual(card.lapses, before_lapses)
                    self.assertEqual(json.loads(card.custom_data)["other"], 42)
                    self.assertEqual(json.loads(card.custom_data)[core.KEY][1], saved)
                    # Real FSRS memory must match the native answer proposal.
                    if fsrs:
                        self.assertIsNotNone(card.memory_state)
                        self.assertAlmostEqual(card.memory_state.stability,
                            getattr(native, name).normal.review.memory_state.stability, places=4)
                    self.advance(7)
                    card = self.col.get_card(card.id)
                    proposed = self.states(card).good.normal.review.scheduled_days
                    prepared, status = self.prepare(card)
                    self.assertEqual(status, "resume")
                    self.answer(card, prepared)
                    self.assertEqual(card.ivl, max(saved, proposed))
                    self.assertNotIn(core.KEY, json.loads(card.custom_data))
                    self.assertEqual(card.lapses, before_lapses)
                    self.advance(card.ivl)
                    card = self.col.get_card(card.id)
                    _, status = self.prepare(card)
                    self.assertEqual(status, "normal")

    def test_first_again_is_native(self):
        card = self.card()
        native = self.states(card)
        prepared, _ = self.prepare(card)
        expected = native.again
        expected.custom_data = "{}"
        self.assertEqual(prepared.again, expected)
        self.answer(card, prepared, CardAnswer.AGAIN)
        self.assertEqual(card.lapses, 1)
        self.assertNotIn(core.KEY, json.loads(card.custom_data or "{}"))

    def test_failed_confirmation_clears_saved_interval(self):
        card = self.card()
        prepared, _ = self.prepare(card)
        self.answer(card, prepared)
        self.advance(7)
        card = self.col.get_card(card.id)
        prepared, _ = self.prepare(card)
        native = self.states(card).again
        native.custom_data = "{}"
        self.assertEqual(prepared.again, native)
        self.answer(card, prepared, CardAnswer.AGAIN)
        self.assertEqual(card.lapses, 1)
        self.assertNotIn(core.KEY, json.loads(card.custom_data or "{}"))
        prepared, status = self.prepare(card)
        self.assertEqual(status, "normal")

    def test_undo_redo_atomic_with_card_and_history(self):
        card = self.card(data='{"other":1}')
        before = card._to_backend_card()
        count = self.col.db.scalar("select count(*) from revlog")
        prepared, _ = self.prepare(card)
        self.answer(card, prepared)
        after = card._to_backend_card()
        self.assertEqual(self.col.db.scalar("select count(*) from revlog"), count + 1)
        self.col.undo()
        card.load()
        self.assertEqual(card._to_backend_card(), before)
        self.assertEqual(self.col.db.scalar("select count(*) from revlog"), count)
        self.col.redo()
        card.load()
        self.assertEqual(card._to_backend_card(), after)

    def test_persists_after_reopen(self):
        card = self.card()
        prepared, _ = self.prepare(card)
        self.answer(card, prepared)
        self.advance(7)
        card = self.col.get_card(card.id)
        self.assertEqual(self.prepare(card)[1], "resume")

    def test_early_review_preserves_due_date(self):
        card = self.card()
        prepared, _ = self.prepare(card)
        saved = prepared.good.normal.review.scheduled_days
        self.answer(card, prepared)
        due = card.due
        self.advance(2)
        card = self.col.get_card(card.id)
        prepared, status = self.prepare(card)
        self.assertEqual(status, "early")
        self.assertEqual(prepared.good.normal.review.scheduled_days, 5)
        self.answer(card, prepared)
        self.assertEqual(card.due, due)
        self.advance(5)
        card = self.col.get_card(card.id)
        self.assertEqual(self.prepare(card)[1], "resume")

    def test_missed_checkpoint_does_not_start_another(self):
        card = self.card()
        prepared, _ = self.prepare(card)
        self.answer(card, prepared)
        self.advance(100)
        card = self.col.get_card(card.id)
        prepared, status = self.prepare(card)
        self.assertEqual(status, "resume")
        self.assertGreater(prepared.good.normal.review.scheduled_days, 7)

    def test_manual_reschedule_invalidates_marker(self):
        card = self.card()
        prepared, _ = self.prepare(card)
        self.answer(card, prepared)
        self.col.sched.set_due_date([card.id], "1")
        card.load()
        prepared, status = self.prepare(card)
        self.assertEqual(status, "cleanup")
        self.assertNotIn(core.KEY, json.loads(prepared.good.custom_data))

    def test_external_review_invalidates_marker(self):
        card = self.card()
        prepared, _ = self.prepare(card)
        self.answer(card, prepared)
        # Simulate another client that syncs custom data but has no add-on.
        card.reps += 1
        self.col.update_card(card)
        prepared, status = self.prepare(card)
        self.assertEqual(status, "cleanup")
        self.assertNotIn(core.KEY, json.loads(prepared.good.custom_data))

    def test_current_maximum_interval_is_respected(self):
        card = self.card()
        prepared, _ = self.prepare(card)
        self.answer(card, prepared)
        self.advance(7)
        card = self.col.get_card(card.id)
        prepared, _ = self.prepare(card, maximum=50)
        self.assertEqual(prepared.good.normal.review.scheduled_days, 50)

    def test_disabled_and_custom_delays(self):
        card = self.card()
        self.assertEqual(self.prepare(card, core.Settings(False))[0], self.states(card))
        prepared, _ = self.prepare(card, core.Settings(True, 30, 3))
        self.assertEqual(prepared.good.normal.review.scheduled_days, 3)

    def test_new_and_relearning_unchanged(self):
        card = self.card()
        card.queue = card.type = 0
        self.col.update_card(card)
        self.assertEqual(self.prepare(card)[0], self.states(card))

    def test_other_scheduler_custom_data_preserved(self):
        card = self.card(data='{"existing":2}')
        states = self.states(card)
        states.good.custom_data = '{"existing":2,"new":3}'
        result, _ = core.prepare(states, core.CardSnapshot.from_card(card), self.col.sched.today, core.Settings())
        data = json.loads(result.good.custom_data)
        self.assertEqual((data["existing"], data["new"]), (2, 3))

    def test_short_native_interval_is_not_delayed(self):
        card = self.card()
        states = self.states(card)
        states.hard.normal.review.scheduled_days = 3
        result, _ = core.prepare(states, core.CardSnapshot.from_card(card), self.col.sched.today, core.Settings())
        self.assertEqual(result.hard.normal.review.scheduled_days, 3)
        self.assertNotIn(core.KEY, json.loads(result.hard.custom_data))

    def test_preview_and_rescheduling_filtered_states(self):
        card = self.card()
        states = self.states(card)
        filtered = SchedulingStates()
        for name in ("current", *core.ANSWERS):
            getattr(filtered, name).filtered.rescheduling.original_state.CopyFrom(getattr(states, name).normal)
        result, status = core.prepare(filtered, core.CardSnapshot.from_card(card), self.col.sched.today, core.Settings())
        self.assertEqual(status, "checkpoint")
        self.assertEqual(result.good.filtered.rescheduling.original_state.review.scheduled_days, 7)
        preview = SchedulingStates()
        preview.current.filtered.preview.scheduled_secs = 10
        result, status = core.prepare(preview, core.CardSnapshot.from_card(card), self.col.sched.today, core.Settings())
        self.assertEqual(result, preview)
        self.assertEqual(status, "preview")

    def test_actual_filtered_deck_returns_checkpoint_to_home_deck(self):
        card = self.card()
        home = card.did
        did = self.col.decks.new_filtered("QA filtered")
        deck = self.col.decks.get(did)
        deck["terms"] = [[f"cid:{card.id}", 100, 0]]
        deck["resched"] = True
        self.col.decks.save(deck)
        self.col.sched.rebuild_filtered_deck(did)
        card.load()
        self.assertEqual(card.odid, home)
        self.assertNotEqual(card.due, card.odue)
        prepared, status = self.prepare(card)
        self.assertEqual(status, "checkpoint")
        self.answer(card, prepared)
        self.assertEqual(card.did, home)
        self.assertEqual(card.odid, 0)
        self.assertEqual(card.due, self.col.sched.today + 7)
        self.assertEqual(card.ivl, 7)
        self.advance(7)
        card = self.col.get_card(card.id)
        self.assertEqual(self.prepare(card)[1], "resume")

    def test_actual_preview_deck_is_untouched(self):
        card = self.card()
        did = self.col.decks.new_filtered("QA preview")
        deck = self.col.decks.get(did)
        deck["terms"] = [[f"cid:{card.id}", 100, 0]]
        deck["resched"] = False
        self.col.decks.save(deck)
        self.col.sched.rebuild_filtered_deck(did)
        card.load()
        prepared, status = self.prepare(card)
        self.assertEqual(status, "preview")
        self.assertEqual(prepared, self.states(card))

    def test_corrupt_marker_never_restores_an_interval(self):
        for marker in ([1, 99999, 0, 1, 7], "invalid", {"interval": 900},
                       [True, 200, 0, 1, 7]):
            card = self.card(overdue=0, data=json.dumps({core.KEY: marker}))
            prepared, status = self.prepare(card)
            self.assertEqual(status, "cleanup")
            self.assertEqual(prepared.good.normal.review, self.states(card).good.normal.review)
            self.assertNotIn(core.KEY, json.loads(prepared.good.custom_data))

    def test_malformed_and_full_custom_data_fail_without_mutating_states(self):
        for data in ('[]', '{broken', json.dumps({"x": "a" * 75})):
            card = self.card()
            snapshot = core.CardSnapshot(card.due, card.ivl, card.reps, data)
            states = self.states(card)
            original = states.SerializeToString()
            with self.assertRaises((ValueError, json.JSONDecodeError)):
                core.prepare(states, snapshot, self.col.sched.today, core.Settings())
            self.assertEqual(states.SerializeToString(), original)

    def test_bad_settings_rejected(self):
        for values in ({"enabled": "false"}, {"checkpoint_days": 0},
                       {"checkpoint_days": 1.5}, {"checkpoint_days": True},
                       {"overdue_days": -1}, {"checkpoint_days": 366}):
            with self.subTest(values=values), self.assertRaises(ValueError):
                core.Settings.from_dict(values)


if __name__ == "__main__":
    unittest.main(verbosity=2)
