import importlib.util
from pathlib import Path
import sys
import tempfile
from types import ModuleType, SimpleNamespace
import unittest
from unittest.mock import patch

from anki.collection import Collection
from test_scheduling import core

ROOT = Path(__file__).resolve().parents[1]
package = ModuleType("qa_checkpoint")
package.__path__ = [str(ROOT / "overdue_checkpoint")]
sys.modules[package.__name__] = package
sys.modules[package.__name__ + ".core"] = core
spec = importlib.util.spec_from_file_location("qa_checkpoint.integration", ROOT / "overdue_checkpoint/integration.py")
integration = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = integration
spec.loader.exec_module(integration)


class IntegrationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.col = Collection(str(Path(self.tmp.name) / "c.anki2"))
        note = self.col.new_note(self.col.models.by_name("Basic"))
        note["Front"] = "Q"
        note["Back"] = "A"
        self.col.add_note(note, 1)
        card = note.cards()[0]
        card.type = card.queue = 2
        card.ivl, card.reps, card.factor = 100, 10, 2500
        card.due = self.col.sched.today - 61
        self.col.update_card(card)
        states = self.col._backend.get_scheduling_states(card.id)
        states.current.custom_data = card.custom_data
        self.config = {}
        self.reviewer = SimpleNamespace(
            _states_mutated=True, card=card,
            get_scheduling_states=lambda: states,
            mw=SimpleNamespace(col=self.col,
                addonManager=SimpleNamespace(getConfig=lambda _: self.config)))

    def tearDown(self):
        self.col.close()
        self.tmp.cleanup()

    def test_repeated_render_and_answer_do_not_overwrite_saved_interval(self):
        states = self.reviewer.get_scheduling_states()
        self.assertTrue(integration.prepare_reviewer(self.reviewer))
        first = states.SerializeToString()
        self.assertTrue(integration.prepare_reviewer(self.reviewer))
        self.assertEqual(states.SerializeToString(), first)
        self.assertEqual(integration.before_answer((True, 3), self.reviewer, self.reviewer.card), (True, 3))
        self.assertEqual(states.SerializeToString(), first)

    def test_async_custom_scheduling_must_finish_before_answer(self):
        self.reviewer._states_mutated = False
        self.assertFalse(integration.prepare_reviewer(self.reviewer))
        self.assertEqual(integration.before_answer((True, 3), self.reviewer, self.reviewer.card), (False, 3))

    def test_existing_cancel_is_respected(self):
        self.assertEqual(integration.before_answer((False, 1), self.reviewer, self.reviewer.card), (False, 1))
        self.assertFalse(hasattr(self.reviewer, "_ocp_prepared_states"))

    def test_buttons_are_prepared_before_native_labels_are_drawn(self):
        def native_show(reviewer):
            self.assertEqual(reviewer.get_scheduling_states().good.normal.review.scheduled_days, 7)
            return "native called"
        self.assertEqual(integration.show_buttons(self.reviewer, native_show), "native called")

    def test_invalid_config_blocks_answer_without_disabling_hook(self):
        self.config["checkpoint_days"] = 0
        with patch.object(integration, "showWarning") as warning:
            self.assertFalse(integration.prepare_reviewer(self.reviewer))
            self.assertFalse(integration.prepare_reviewer(self.reviewer))
            warning.assert_called_once()
        self.config["checkpoint_days"] = 7
        self.assertTrue(integration.prepare_reviewer(self.reviewer))


if __name__ == "__main__":
    unittest.main(verbosity=2)
