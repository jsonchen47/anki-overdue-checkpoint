# Overdue Checkpoint

An Anki desktop add-on that asks for a short follow-up before giving a very overdue card its next long interval.

With the defaults, a review card **more than 60 days overdue** comes back in **7 days** after Hard, Good, or Easy. Passing that follow-up restores the interval Anki originally proposed, or Anki's new proposal if longer. Again uses normal relearning and discards the saved interval.

Example: Anki proposes 300 days for a card answered 90 days late. The add-on schedules it in 7 days. Recall on that day restores 300 days, or a longer interval if Anki proposes one. Forgetting it uses the deck's ordinary lapse settings.

## Install

1. In desktop Anki, choose **Tools → Add-ons → Install from file**.
2. Select `dist/overdue-checkpoint-0.1.0.ankiaddon`.
3. Restart Anki.
4. Open **Tools → Overdue Checkpoint settings…** to adjust the threshold and delay.

The rule takes effect when you answer a card. Installation does not reschedule existing cards in bulk. The due date appears on the answer buttons, and a brief message identifies the checkpoint.

## Behavior and limits

- “Two months” means 60 days, measured from the card's due date, using Anki's study-day boundary.
- A card exactly 60 days overdue keeps normal scheduling. The default rule starts at 61 days overdue.
- Hard, Good, and Easy count as remembered. Again counts as forgotten.
- If Anki already proposes 7 days or less, that shorter interval stays in place.
- Reviewing early keeps the original follow-up date. A late follow-up completes the pending check instead of starting another.
- The deck's current maximum interval limits the resumed interval.
- New and learning cards are unaffected. Rescheduling filtered decks are supported; preview-only filtered decks are unchanged.
- Saved state belongs to each card, so sibling cards do not share a checkpoint. It is committed with the real answer and participates in Anki's undo, redo, save, and sync.
- Manual rescheduling, resetting, or answering on another client can invalidate a saved checkpoint. Stale saved intervals are discarded.
- This add-on runs in **desktop Anki**. Mobile clients receive due dates through sync but do not run its checkpoint or interval-restoration logic. Complete both reviews on desktop with the add-on enabled.
- FSRS and SM-2 were tested. The add-on deliberately changes due intervals; FSRS memory states and actual ratings are preserved. Bulk FSRS rescheduling or another scheduling add-on can replace the checkpoint date. Restoring a saved interval can differ from FSRS's latest retention-based proposal.
- Disabling or removing the add-on leaves existing due dates in place. Subsequent reviews use normal Anki scheduling. To restore a saved long interval, keep the add-on enabled through the follow-up.
- Card custom data has a 100-byte limit. If there is insufficient space or configuration is invalid, the add-on explains the issue and blocks that answer without committing changes.

## Compatibility

Release candidate **0.1.0** is tested and packaged for **Anki 25.09.4**, the version installed during development. Other Anki releases, Windows, Linux, and combinations with third-party scheduling add-ons have not been tested. The add-on wraps one private UI method to prepare scheduling states after custom JavaScript finishes and before native interval labels render; future Anki changes may require an update.

No network requests, external dependencies, analytics, note edits, or global custom scheduling changes are made by the add-on.

## Development

Use a Python environment with matching `anki` and `aqt` packages:

```bash
python -m unittest discover -s tests -v
python tests/gui_smoke.py
python tests/gui_smoke.py --fsrs
python build.py
```

Scheduler tests use synthetic temporary collections and Anki's actual Rust backend. The GUI test starts an isolated Anki profile with a unique instance socket, installs the built package, and exercises native review buttons and settings. It never opens a personal collection or uses a sync account. Results and screenshots are in `test-results/`.

The archive has a flat file layout and deterministic timestamps. Test code and personal data are excluded. The add-on is published on [AnkiWeb](https://ankiweb.net/shared/info/1501454025), with installation code `1501454025`. The illustrated instructions are in `USER-GUIDE.md`, and the public listing text is in `ANKIWEB-LISTING.md`.
