**Overdue Checkpoint**

- `enabled`: turn the rule on or off. Restart the review session after changing this.
- `overdue_days`: cards must be **more than** this many days past their due date. Default: 60 days, an approximation of two months.
- `checkpoint_days`: the delay before confirming recall. Default: 7 days.

Hard, Good, and Easy count as recall. Again uses Anki's normal lapse behavior and clears the saved interval. Cards Anki already schedules within the checkpoint delay keep their shorter interval.

Passing the check restores the interval Anki proposed before the check, or its new proposal if longer, limited by the deck's current maximum interval. Early reviews keep the original check date.

Applies to reviews made in **desktop Anki with this add-on enabled**, including filtered decks that reschedule. Preview-only filtered decks are unchanged. Other clients receive the due dates through sync, but do not run this rule.

This deliberately overrides intervals, including with FSRS. FSRS memory state and real answer ratings remain intact. Other add-ons that reschedule cards or a bulk FSRS reschedule can supersede the check. Disabling or removing the add-on leaves already-scheduled checks due; subsequent answers use normal Anki scheduling.
