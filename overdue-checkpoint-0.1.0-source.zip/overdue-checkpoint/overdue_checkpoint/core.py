"""Scheduling policy. No database writes: commit through Anki's answer operation."""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

KEY = "ocp"
MAX_CUSTOM_BYTES = 100
ANSWERS = ("again", "hard", "good", "easy")


@dataclass(frozen=True)
class Settings:
    enabled: bool = True
    overdue_days: int = 60
    checkpoint_days: int = 7

    @classmethod
    def from_dict(cls, value: dict[str, Any]) -> Settings:
        enabled = value.get("enabled", True)
        if type(enabled) is not bool:
            raise ValueError("enabled must be true or false")
        numbers = []
        for key, default, maximum in (
            ("overdue_days", 60, 36500), ("checkpoint_days", 7, 365),
        ):
            number = value.get(key, default)
            if type(number) is not int or not 1 <= number <= maximum:
                raise ValueError(f"{key} must be an integer from 1 to {maximum}")
            numbers.append(number)
        return cls(enabled, *numbers)


@dataclass(frozen=True)
class CardSnapshot:
    due: int
    interval: int
    reps: int
    custom_data: str

    @classmethod
    def from_card(cls, card: Any) -> CardSnapshot:
        return cls(card.odue if card.odid else card.due,
                   card.ivl, card.reps, card.custom_data)


def normal_state(state: Any) -> Any | None:
    kind = state.WhichOneof("kind")
    if kind == "normal":
        return state.normal
    if kind == "filtered" and state.filtered.WhichOneof("kind") == "rescheduling":
        return state.filtered.rescheduling.original_state
    return None


def _data(raw: str) -> dict[str, Any]:
    value = json.loads(raw or "{}")
    if not isinstance(value, dict):
        raise ValueError("Card custom data must be a JSON object")
    return value


def _encode(value: dict[str, Any]) -> str:
    raw = json.dumps(value, separators=(",", ":"), ensure_ascii=True)
    if len(raw.encode("utf-8")) > MAX_CUSTOM_BYTES:
        raise ValueError("Not enough space in card custom data (100-byte limit)")
    return raw


def _valid_marker(value: Any, card: CardSnapshot) -> bool:
    # [schema version, saved interval, due day, expected repetitions, check interval]
    return (isinstance(value, list) and len(value) == 5
            and all(type(v) is int for v in value)
            and value[0] == 1 and 1 <= value[1] <= 36500
            and value[2] == card.due and value[3] == card.reps
            and 1 <= value[4] <= 365 and value[4] == card.interval)


def prepare(states: Any, card: CardSnapshot, today: int,
            settings: Settings, maximum_interval: int = 36500) -> tuple[Any, str]:
    """Return independent states and status; leave the input untouched on error.

    Only outgoing scheduled_days/custom_data change. Memory state, ratings,
    ease, lapses and current state stay under Anki's control.
    """
    result = type(states)()
    result.CopyFrom(states)
    if not settings.enabled:
        return result, "disabled"
    current = normal_state(states.current)
    if current is None:
        return result, "preview"
    data = _data(card.custom_data)
    marker = data.get(KEY)
    pending = _valid_marker(marker, card)
    is_review = current.WhichOneof("kind") == "review"
    overdue = today - card.due
    start = is_review and not pending and overdue > settings.overdue_days
    # A stale marker (manual reschedule, reset, or review on another client)
    # must never restore an obsolete long interval.
    cleanup = KEY in data and not pending
    if not (start or pending or cleanup):
        return result, "normal"
    status = "checkpoint" if start else "resume" if pending else "cleanup"
    if pending and today < card.due:
        status = "early"
    for name in ANSWERS:
        incoming = getattr(states, name)
        outgoing = getattr(result, name)
        branch = normal_state(outgoing)
        if branch is None:
            continue
        # Preserve changes made by other custom schedulers on each answer.
        branch_data = _data(incoming.custom_data if incoming.HasField("custom_data")
                            else card.custom_data)
        branch_data.pop(KEY, None)
        correct = name != "again" and branch.WhichOneof("kind") == "review"
        if correct and start:
            saved = branch.review.scheduled_days
            # Anki already wants the card back within a week. There is no long
            # interval to gate, and postponing that review would be counterproductive.
            if saved > settings.checkpoint_days:
                delay = min(settings.checkpoint_days, maximum_interval)
                branch.review.scheduled_days = delay
                branch_data[KEY] = [1, saved, today + delay, card.reps + 1, delay]
        elif correct and pending and is_review:
            if today < card.due:
                delay = card.due - today
                branch.review.scheduled_days = delay
                branch_data[KEY] = [1, marker[1], card.due, card.reps + 1, delay]
            else:
                # Never multiply the temporary seven-day interval into a new
                # long interval. Resume the saved proposal, or a longer native
                # proposal, subject to the deck's current maximum interval.
                branch.review.scheduled_days = min(
                    maximum_interval, max(marker[1], branch.review.scheduled_days))
        outgoing.custom_data = _encode(branch_data)
    return result, status
