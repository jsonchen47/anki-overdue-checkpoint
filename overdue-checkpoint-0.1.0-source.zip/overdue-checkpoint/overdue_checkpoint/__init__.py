"""Overdue Checkpoint add-on for desktop Anki."""
from . import integration

integration.install(__name__)
