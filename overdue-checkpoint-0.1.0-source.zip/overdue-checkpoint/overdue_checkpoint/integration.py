from __future__ import annotations

from anki.hooks import wrap
from aqt import gui_hooks, mw
from aqt.qt import (QAction, QCheckBox, QDialog, QDialogButtonBox,
                    QFormLayout, QLabel, QSpinBox)
from aqt.reviewer import Reviewer
from aqt.utils import showWarning, tooltip

from .core import CardSnapshot, Settings, prepare

_package = ""
_installed = False


def prepare_reviewer(reviewer: Reviewer) -> bool:
    """Run after native JS finishes, before labels are drawn or an answer commits."""
    if not reviewer._states_mutated:
        return False
    states = reviewer.get_scheduling_states()
    if getattr(reviewer, "_ocp_prepared_states", None) is states:
        return True
    card = reviewer.card
    if card is None:
        return False
    try:
        config = reviewer.mw.addonManager.getConfig(_package) or {}
        settings = Settings.from_dict(config)
        col = reviewer.mw.col
        deck = col.decks.config_dict_for_deck_id(card.odid or card.did)
        maximum = deck["rev"]["maxIvl"]
        updated, status = prepare(states, CardSnapshot.from_card(card),
                                  col.sched.today, settings, maximum)
    except ValueError as exc:
        error = (card.id, str(exc))
        if getattr(reviewer, "_ocp_last_error", None) != error:
            reviewer._ocp_last_error = error
            showWarning(f"Overdue Checkpoint cannot prepare this card: {exc}.\n\n"
                        "The card has not been answered. Correct the add-on configuration "
                        "or disable Overdue Checkpoint and restart Anki to use normal scheduling.")
        return False
    states.CopyFrom(updated)
    reviewer._ocp_prepared_states = states
    reviewer._ocp_status = status
    return True


def show_buttons(reviewer: Reviewer, _old):
    if reviewer._states_mutated:
        prepare_reviewer(reviewer)
    return _old(reviewer)


def before_answer(ease_tuple, reviewer, card):
    if not ease_tuple[0]:
        return ease_tuple
    if not prepare_reviewer(reviewer):
        return False, ease_tuple[1]
    return ease_tuple


def show_status(card):
    reviewer = mw.reviewer
    if getattr(reviewer, "_ocp_prepared_states", None) is not reviewer.get_scheduling_states():
        return
    status = getattr(reviewer, "_ocp_status", "normal")
    if status == "checkpoint":
        days = (mw.addonManager.getConfig(_package) or {}).get("checkpoint_days", 7)
        tooltip(f"Overdue Checkpoint: remembered cards return within {days} days.",
                period=3000)
    elif status == "resume":
        tooltip("Overdue Checkpoint: recall passes the check and restores the regular interval.",
                period=3000)
    elif status == "early":
        tooltip("Overdue Checkpoint: this early review does not skip the scheduled check.",
                period=3000)


def config_updated(config):
    try:
        Settings.from_dict(config)
    except ValueError as exc:
        showWarning(f"Overdue Checkpoint: {exc}. Correct the configuration before reviewing.")
    # Return to overview instead of reusing already-mutated answer states.
    if mw.col and mw.state == "review":
        mw.moveToState("overview")


def open_settings():
    config = mw.addonManager.getConfig(_package) or {}
    settings = Settings.from_dict(config)
    dialog = QDialog(mw)
    dialog.setWindowTitle("Overdue Checkpoint")
    dialog.setMinimumWidth(480)
    layout = QFormLayout(dialog)
    enabled = QCheckBox("Enable overdue checks")
    enabled.setChecked(settings.enabled)
    threshold = QSpinBox()
    threshold.setRange(1, 36500)
    threshold.setValue(settings.overdue_days)
    threshold.setSuffix(" days")
    delay = QSpinBox()
    delay.setRange(1, 365)
    delay.setValue(settings.checkpoint_days)
    delay.setSuffix(" days")
    layout.addRow(enabled)
    layout.addRow("More than this far overdue:", threshold)
    layout.addRow("Confirm recall after:", delay)
    description = QLabel(
        "Hard, Good, and Easy count as remembered. Again uses normal relearning.\n"
        "Passing the check restores the saved regular interval.\n"
        "Applies to reviews in desktop Anki while this add-on is enabled.")
    description.setWordWrap(True)
    layout.addRow(description)
    buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok
                              | QDialogButtonBox.StandardButton.Cancel)
    buttons.accepted.connect(dialog.accept)
    buttons.rejected.connect(dialog.reject)
    layout.addRow(buttons)
    if dialog.exec() == QDialog.DialogCode.Accepted:
        config.update(enabled=enabled.isChecked(), overdue_days=threshold.value(),
                      checkpoint_days=delay.value())
        mw.addonManager.writeConfig(_package, config)
        config_updated(config)


def install(package: str):
    global _package, _installed
    if _installed:
        return
    _package = package
    if not hasattr(Reviewer, "get_scheduling_states"):
        showWarning("Overdue Checkpoint requires Anki 25.09.4 or later.")
        return
    Reviewer._showEaseButtons = wrap(Reviewer._showEaseButtons, show_buttons, "around")
    gui_hooks.reviewer_will_answer_card.append(before_answer)
    gui_hooks.reviewer_did_show_answer.append(show_status)
    mw.addonManager.setConfigUpdatedAction(package, config_updated)
    action = QAction("Overdue Checkpoint settings…", mw)
    action.triggered.connect(open_settings)
    mw.form.menuTools.addAction(action)
    _installed = True
